# KR Patch by Cyma
Cyma님의 한글패치 v0.2.410 버전의 내용물을 모아놓았습니다.<br/><br/>

- 이 폴더에 대한 Pull Request는 승인하지 않습니다. 
